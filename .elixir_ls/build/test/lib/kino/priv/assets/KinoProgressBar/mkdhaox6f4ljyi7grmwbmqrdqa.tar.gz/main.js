export function init(ctx, html) {
  ctx.root.innerHTML = html;

  ctx.handleEvent("update", ({max, value}) => {
    console.log(value);
    let pb = document.getElementById("kino_pb");
    if (max) {pb.max = max;}
    if (!value) {
      pb.removeAttribute('value')
    } else{
      pb.value = value;
    }
  });
}
